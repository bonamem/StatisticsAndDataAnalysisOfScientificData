import math
import numpy as np
import matplotlib.ticker as tick
import scipy.stats as stats

from scipy.stats import poisson
from scipy.stats import uniform
from cstatFunctions import  flinear,cminLinear,fa,faprime,bestFitLnum,bestFitL,bestFitA,ga
from matplotlib import pyplot as plt
from scipy.optimize import curve_fit,root_scalar
from scipy.optimize import fsolve
from matplotlib.ticker import StrMethodFormatter
from matplotlib.ticker import ScalarFormatter
from matplotlib.ticker import FuncFormatter
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams.update({'font.size': 18})
plt.rcParams['axes.linewidth'] = 2.0
plt.rcParams['figure.figsize'] = 5,5
plt.rcParams.update({'figure.autolayout': True})


# =====================================================
# Figure 1 ============================================
# parameters of the data ==============================
N=10
xA=0. #starting point of x-axis, 1/2 bin to the left of x[0]
xB=N
Deltax=1 # size of each bin, assumed uniform in this example
# xbin has the mid-point of each bin
xbin=np.arange(Deltax/2.,N+Deltax/2.,1)
R=xbin[N-1]-xbin[0]+Deltax # range of independent variable
l=1
a=1/R

ymodel=np.zeros(N)

for i in range(N):
        ymodel[i]=flinear(xbin[i],xA,l,a)

plt.figure(figsize=(8, 5))
print('xA,xB',xA,xB)
plt.tick_params(axis='y', direction='in',which='both', labelleft='false', labelright='true',width=2,length=6)
plt.tick_params(axis='x',width=2,length=8)
plt.xticks([xA,0.5,1.5,2.5,3.5,4.5,5.5,6.5,7.5,8.5,9.5,xB],('\n$\mathbf{x_A}$','$x_1$','','','$x_i$','$x_{i+1}$','','','','','$x_{N}$','\n$\mathbf{x_B}$'))
plt.yticks([l,l*(1+a*R)],('$\lambda$','$\lambda(1+aR)$'),rotation='vertical',va='center')
plt.plot([xA,xB],[flinear(xA,xA,l,a),flinear(xB,xA,l,a)],color='black',linewidth=2,label='linear model $f(x)=\lambda(1+a(x-x_A))$')
plt.step(xbin,ymodel,where='mid',color='black',linewidth=2,linestyle='--',label='step-wise linear model $y(x_i)$')
# add the two 1/2 missing steps
plt.hlines(ymodel[0],xbin[0]-Deltax/2,xbin[0],linestyle='--',color='black',linewidth=2)
plt.hlines(ymodel[N-1],xbin[N-1],xbin[N-1]+Deltax/2.,linestyle='--',color='black',linewidth=2)
# ==============================
plt.xlabel('')
plt.ylabel('y (dependent variable)')
plt.grid(axis='y')
plt.vlines(N,1,2,color="red",linewidth=2)
plt.vlines(N,0,1,linestyle='--',color="red")
plt.vlines(0,0,1,linestyle='--',color="red")
plt.vlines(3.5,0,ymodel[3],linestyle='--',color="green",linewidth=2)
plt.vlines(4.5,0,ymodel[4],linestyle='--',color="green",linewidth=2)
plt.hlines(1,xA,xB,color='blue',linewidth=2)
plt.legend(loc=2)

#plt.annotate('',xy=(N+0.2,1),xytext=(N+0.2,2),arrowprops=dict(facecolor='red', color='red',arrowstyle='|-|'))
plt.text(N+0.2,1.5,'$\lambda a R$',color='red',rotation=90)
#plt.arrow(N+0.1,1,0,1,shape='full',color='red',linestyle='-',width=0.02,length_includes_head='true',head_width=0.1)
#bbox_props = dict(boxstyle="darrow,pad=0.3", fc="cyan", ec="b", lw=2)
plt.text(5,1.05,"$R$",color='blue')#,bbox=bbox_props)
#plt.annotate('',xy=(3,1.5),xytext=(4,1.5),arrowprops=dict(facecolor='red', color='red',arrowstyle='|-|'))
plt.hlines(1.4,3.,4.,color="green",linewidth=2)
plt.text(3.2,1.45,'$\Delta x_i$',color="green")
plt.xlim(-1,N+1)
plt.ylim(0.5,2.3)
plt.show()
# =========== end Fig. 1 =================================


# Figure 4 ===============================================
# Now plot the intervals of acceptability of "a" solutions
Deltax=1
R=100
xA=0
xB=10
# this is a/(R/2), i.e., a rescaled by R/2
a=np.arange(-2*R/(Deltax),R+1,0.01)
M=1
Lambda=np.zeros(len(a))
for i in range(len(a)):
	Lambda[i]=M/R/(1+a[i])

plt.figure(figsize=(7, 7))
#plt.axis('off')
plt.xlim(-2*R,0.3*R)
plt.ylim(-0.012,0.012)
plt.plot(a,Lambda,color='black',linewidth=3,label='$\lambda(a)/M$')
plt.vlines(-R/Deltax,-0.12,0.12,color='blue',label='$a=-2/\Delta x_1$')
plt.vlines(-1/2,-0.12,0.12,color='red',label='$a=-1/(R-\Delta x_N/2)$')
# scale the x axis as a/(R/2)
plt.xscale('symlog',linthreshx=1.,linscalex=.4)
plt.xticks([-R/Deltax,-1,-0.5,0],('','$-1$','','0'))
plt.yticks([-0.01,0.0,0.01],('-0.01','0','0.01'))
plt.tick_params(axis='y', right=True,labelright=True,which='both',left=True, labelleft=False,labelrotation=90)
plt.tick_params(axis='x',width=2,length=8)
plt.grid(axis='x',linewidth=2, linestyle='--')
plt.hlines(0,min(a),max(a),linewidth=2, linestyle='--')
#plt.vlines(-1,-0.012,0.012,color='blue',linestyle='--',label='Singularity ($a=-2/R$)',linewidth=4)
plt.xlabel('Normalized parameter $a/(R/2)$')
plt.ylabel('Normalized parameter $\lambda(a)/M$')
plt.fill([-R/Deltax,-R/Deltax,-1/2,-1/2],[-1,1,1,-1],facecolor="none",alpha=0.7,hatch='/',edgecolor='black',label='Unacceptable solutions of $F(a)=0$')
plt.fill([-R/Deltax,-R/Deltax,-1/2,-1/2],[-1,1,1,-1],"yellow",alpha=0.5,label='Range of singularities of $F(a)$')
plt.legend(loc=2,prop={'size': 12})
#plt.text(-0.8*R,0.006,"Unacceptable solutions",fontsize=13,bbox=dict(facecolor='red', alpha=0.5))
plt.show()
# ======= end Fig. 4 =====================================

# Fig. 7 ====================================================
# Make a plot of % of datasets with unacceptable solutions, as function of M
# and % of datasets with negative asymptotic value

accept0=np.genfromtxt("acceptRatio-a0.txt")
accept1=np.genfromtxt("acceptRatio-a+0.01.txt")
accept2=np.genfromtxt("acceptRatio-a-0.01.txt")
accept=(accept0,accept1,accept2)

print(accept[0][:,1])
n=len(accept[0][:,1]) # assuming all files of same length ...
m=np.zeros((3,n),dtype=float)
frac=np.zeros((3,n),dtype=float)
fracErr=np.zeros((3,n),dtype=float)
fracPlus=np.zeros((3,n),dtype=float)
fracMinus=np.zeros((3,n),dtype=float)
Finf=np.zeros((3,n),dtype=float)
FinfPlus=np.zeros((3,n),dtype=float)
FinfMinus=np.zeros((3,n),dtype=float)
FinfErr=np.zeros((3,n),dtype=float)
colors=['red','green','blue']
labelText=['uniform','positive slope','negative slope']
for j in range(3):
	m[j]=accept[j][:,1]
	frac[j]=accept[j][:,2]
	Finf[j]=1-accept[j][:,3]
	N=100 # this is the number of simulations
	# also estimate an error for the simulations, var = N p q since it's a binomial
	for i in range(n):
#		if m[i]>20:
#			N=100
		fracErr[j,i]=(N*frac[j,i]*(1.-frac[j,i]))**0.5/(N*frac[j,i])
		FinfErr[j,i]=(N*Finf[j,i]*(1.-Finf[j,i]))**0.5/(N*Finf[j,i])
		fracPlus[j,i]=frac[j,i]+fracErr[j,i]
		FinfPlus[j,i]=Finf[j,i]+FinfErr[j,i]
		fracMinus[j,i]=frac[j,i]-fracErr[j,i]
		FinfMinus[j,i]=Finf[j,i]-FinfErr[j,i]
		if fracPlus[j,i]>1.0:
			fracPlus[j,i]=1.0
		if FinfPlus[j,i]>1.0:
			FinfPlus[j,i]=1.0
		if fracMinus[j,i]<0.0:	
			fracMinus[j,i]=0.0
		if FinfMinus[j,i]<0:
			FinfMinus[j,i]=0
	print(m[j],frac[j],fracErr[j])
	plt.xlim(2,200)
	plt.semilogx(m[j],frac[j],linewidth=2,color='black')
#plt.semilogx(m,fracPlus)
#plt.semilogx(m,fracMinus)
	plt.fill_between(m[j],fracMinus[j],fracPlus[j],color=colors[j],alpha=0.5,label=labelText[j])

plt.xticks([2,5,10,20,50,100,200],['2','5','10','20','50','100','200'])
plt.xlabel('Number of counts M')
plt.ylabel('Fraction with acceptable model')
plt.legend(loc=4,prop={'size': 10})
plt.hlines(1,2,200,linestyle='--',color='black')
plt.show()

plt.xlim(2,200)
plt.xlabel('Number of counts M')
plt.ylabel('Fraction with $F_{\infty}<0$')
plt.hlines(1,2,200,linestyle='--',color='black')
for j in range(3):
	plt.semilogx(m[j],Finf[j],linewidth=2,color='black')
	plt.fill_between(m[j],FinfMinus[j],FinfPlus[j],color=colors[j],alpha=0.5,label=labelText[j])
plt.legend(loc=4,prop={'size': 10})
plt.show()
# =========== end Fig. 7 ========================================
