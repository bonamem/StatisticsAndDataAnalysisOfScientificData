import math
import numpy as np
import matplotlib.ticker as tick
import scipy.stats as stats
import statistics
from scipy.stats import poisson
from scipy.stats import uniform
from cstatLinearFunction import bestFitLinear,bestFitLinearExtended
from cstatFunctions import fAsymptotic

# ==========================================================
# define how many simulations and counts (M) in each simulation
Mvalues=[2,3,4,5,6,7,8,9,10,12,15,20,30,50,70,100,150,200,500,1000]
NSim=100# number of simulated datasets
# ==========================================================

# define the data ==========================================
N=100 	# number of datapoints
xA=0. #starting point of x-axis, 1/2 bin to the left of x[0]
Deltax=1 # size of each bin, assumed uniform in this example
Deltax=Deltax*np.ones(N)
# xbin has the mid-point of each bin
hasGap=0
xbin=np.arange(0.5,N+0.5,1)
# ==========================================================a

res=np.zeros(NSim)
Lambda=np.zeros(NSim)
cstat=np.zeros(NSim)
hasConverged=np.zeros(NSim, dtype=int)
hasPositiveFinf=np.zeros(NSim, dtype=int)
y=np.zeros((NSim,N),dtype=int) # all zeros to begin with

fratio=open("acceptRatio.txt","w")

# ===================================
# decide which model to simulate
modelNumber=3
# 1: constant model
# 2: increasing model
# 3: decreasing model
# ==================================
for k in range(len(Mvalues)):
	M=Mvalues[k]
	print("M=%d"%M)
	simIndex=np.zeros((NSim,M),dtype=int)
	randomFloats=np.zeros((NSim,M),dtype=float)
	nAccept=0
	for i in range(NSim):
                # 1. M random indices between 0 and N-1
		if (modelNumber==1):
			simIndex[i]=np.random.randint(0,N,size=M)
                # ==================================
                # If we want to use a non-uniform distribution, got to change this
                # 2. This is for an increasing f(x)=2x , x in 0,1, distribution
		if (modelNumber==2):
			randomFloats[i]=N*(np.random.uniform(0,1,M)**0.5)
			simIndex[i]=randomFloats[i]
                # 3. This is for a decreasing, 2-2x distribution
		if (modelNumber==3): 
			randomFloats[i]=N*(1-np.random.uniform(0,1,M)**0.5)
			simIndex[i]=randomFloats[i]
                # =====================================================
                #print('Simulated indices',simIndex[i])
                # Need to reset the data
		y[i]=np.zeros(N)
		for j in range(M):
			y[i,simIndex[i,j]]+=1 # possibility of a bin with >1 counts
		data=(xbin,y[i],xA,Deltax)
		# =======================================================================
		# This is the main function "bestFitLinear"
		hasConverged[i],res[i],Lambda[i],cstat[i]=bestFitLinear(data,hasGap,data)
		# =======================================================================
		if hasConverged[i]==1:
			nAccept+=1
                # also check the sign of F_infinity for that data
		Finf=fAsymptotic(data)
		hasPositiveFinf[i]=np.sign(Finf) # +-1 is returned
	acceptRatio=nAccept/NSim
	positiveFinfRatio=sum(map(lambda x : x==1, hasPositiveFinf))/NSim
	fratio.write("%d %d %3.3f %3.3f\n"%(k, M,acceptRatio,positiveFinfRatio))
	print("%d of %d simulations for M=%d had acceptable solution (fraction: %3.3f)"%(nAccept,NSim,M,acceptRatio))
fratio.close()
